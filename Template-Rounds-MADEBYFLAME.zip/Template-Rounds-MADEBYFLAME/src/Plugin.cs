﻿using BepInEx;
using UnityEngine;

namespace BepInExPlugin
{
    [BepInPlugin(PluginInfo.PLUGIN_ID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
    public class Plugin : BaseUnityPlugin
    {
        private bool IsGuiOn = false;

        private void OnGUI()
        {
            GUI.Label(new Rect(10, 10, 100, 20), "GUI TEMP By Flame");
            GUI.color = Color.magenta;
            GUI.backgroundColor = Color.blue;
            GUI.contentColor = Color.magenta;

            if (GUI.Button(new Rect(10, 40, 100, 20), IsGuiOn ? "GUI : ON" : "GUI : OFF"))
            {
                IsGuiOn = !IsGuiOn;
            }


            if (IsGuiOn)
            {
                {
                    GUI.Box(new Rect(10, 70, 400, 400), "(FLAMES TEMP) !THIS IS THE SECOND EVER IN ROUNDS!");
                    // BUTTONS
                    if (GUI.Button(new Rect(15, 105, 120, 30), "1"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 145, 120, 30), "2"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 185, 120, 30), "3"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 225, 120, 30), "4"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 265, 120, 30), "5"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 305, 120, 30), "5"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 345, 120, 30), "6"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 385, 120, 30), "7"))
                    {

                    }

                    if (GUI.Button(new Rect(15, 425, 120, 30), "8"))
                    {

                    }
                }
            }
            else
            {

            }
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                IsGuiOn = !IsGuiOn;
            }

        }
    }
}